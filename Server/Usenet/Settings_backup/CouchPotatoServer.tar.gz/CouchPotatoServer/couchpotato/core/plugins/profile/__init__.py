from .main import ProfilePlugin


def autoload():
    return ProfilePlugin()
